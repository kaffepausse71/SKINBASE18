# skin.CarPc-Carbon Kodi 18

If you find some problems you can write me.

The skin in action https://youtu.be/0peOkS6z_aU 

If you like this skin you can by me a bear [![](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=AMXESTYHM96HN)

or 

You can subscribe to my Youtube chanel !

[![](http://www.freeiconspng.com/uploads/youtube-subscribe-png-23.png)](https://www.youtube.com/user/idorel11?sub_confirmation=1)

This skin is base on skin.estouchy



