Night for KODI
==============
Night is a beautiful, clean and Fanart focused Skin for KODI. Design is based on Night Skin by mcborzu, rewritten by bkury.

Forum         : https://bit.ly/night4kodi
Translations  : https://bit.ly/translatenight
Donate        : https://paypal.me/bkury

[![Donate](https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=support%40kury%2eorg&lc=US&item_name=Night%20Skin&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_LG%2egif%3aNonHostedGuest)
