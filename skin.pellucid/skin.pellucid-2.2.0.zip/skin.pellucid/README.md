Pellucid
===================

Pellucid is a skin for Kodi Media Centre.

Built for the living room, Pellucid is a clean and carefully designed Kodi experience designed for maximum usability and minimum fuss.

#### Additional features

- Skin Shortcuts addon support.
- Full PVR / Live TV support

Discussion thread: http://forum.kodi.tv/forumdisplay.php?fid=267

Additional homescreen wallpapers provided by Dadebue (https://www.instagram.com/dadebue/)

Created by theDeadMan.

