# T[COLOR yellow]e[/COLOR]rror L[COLOR yellow]i[/COLOR]TE 5: Terror
A modded version of [T[COLOR yellow]e[/COLOR]rror L[COLOR yellow]i[/COLOR]TE 5](http://forum.kodi.tv/showthread.php?tid=183504)

**Branches guide:**
 - **master:** Kodi v18 Codename Leia
 - **krypton:** Kodi v17 Codename Krypton
 - **jarvis:** Kodi v16 Codename Jarvis
 - **isengard:** Kodi v15 Codename Isengard
 - **helix:** Kodi v14 Codename Helix

*Check the [T[COLOR yellow]e[/COLOR]rror L[COLOR yellow]i[/COLOR]TE 5: Terror thread](http://forum.kodi.tv/showthread.php?tid=210069) for more information and support*

**ALL OTHER BRANCHES SHOULD NOT BE USED OR INSTALLED**
