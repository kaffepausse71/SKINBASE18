# Skin Titan BINGIE

The new Titan for Kodi Leia...

#IMPORTANT NOTE FOR USERS# 
Install the skin through the official bingie repository for updates and the supported addons required!
The content here is for developing purposes!
https://github.com/cartmandos/repository.bingie

Join the official thread for updates: https://forum.kodi.tv/showthread.php?tid=334820

Special Thanks to @marcelveldt for all of his work on the original code for Titan skin & addons.
Thanks to @marduklev for helping out all along the way and a lot of great ideas!
Thanks to @sualfred and @jurialmunkey for setting the example of how to be awsome in coding practices!
and everyone else who have helped or contributed in any way!
